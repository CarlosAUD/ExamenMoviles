// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyCjkBhsC30j8US5cxaq-6ysOIZWddOsUiw",
    authDomain: "moviles7777.firebaseapp.com",
    projectId: "moviles7777",
    storageBucket: "moviles7777.firebasestorage.app",
    messagingSenderId: "559453331002",
    appId: "1:559453331002:web:00db1a3b731ecd53691f03",
    measurementId: "G-7YF67KXC31"
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
