import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datos-list',
  templateUrl: './datos-list.page.html',
  styleUrls: ['./datos-list.page.scss'],
})
export class DatosListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
