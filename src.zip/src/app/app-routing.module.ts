import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'app-list',
    loadChildren: () => import('./pages/datos-list/datos-list.module').then(m => m.DatosListPageModule)
  },  
  { path: '', redirectTo: 'app-list', pathMatch: 'full' },
  { path: 'app-list', loadChildren: () => import('./pages/detail-list/detail-list.module').then(m => m.DetailListPageModule) },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }