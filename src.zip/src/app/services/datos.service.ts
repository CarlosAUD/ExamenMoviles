import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root' // Asegúrate de que el servicio está disponible globalmente
})
export class DatosService {

  private booksApiUrl = 'https://api.example.com/books';  // URL de la API de libros
  private dogApiUrl = 'https://dog.ceo/api/breeds/image/random';  // URL de la API de perros
  private robotApiUrl = 'https://robohash.org/';  // URL de la API de robots

  constructor(private http: HttpClient) {}

  // Obtener los libros
  getBooks(): Observable<any> {
    return this.http.get<any>(this.booksApiUrl);
  }

  // Obtener una imagen aleatoria de perro
  getRandomDogImage(): Observable<any> {
    return this.http.get<any>(this.dogApiUrl);
  }

  // Obtener una imagen aleatoria de robot
  getRandomRobotImage(id: string): Observable<any> {
    return this.http.get<any>(`${this.robotApiUrl}${id}?set=set4`);
  }
}
