import { Component, OnInit } from '@angular/core';
import { DatosService } from '../services/datos.service';  // Importar el servicio de datos
import { Firestore, collection, addDoc } from '@angular/fire/firestore';

@Component({
  selector: 'app-home',  
  templateUrl: './home.page.html',  
  styleUrls: ['./home.page.scss'], 
})
export class HomePage implements OnInit {
  bookList: { title: string; image: string }[] = [];

  constructor(private datosService: DatosService, private firestore: Firestore) {}

  ngOnInit() {
    this.loadBooks();
  }

  loadBooks() {
    this.bookList = [];  // Limpiar la lista de libros

    this.datosService.getBooks().subscribe((response: any) => {
      // Verificar si la respuesta contiene 'results'
      if (response && response.results) {
        const books = response.results; // Suponiendo que 'results' contiene la lista de libros

        books.forEach((book: { title: string }, index: number) => {
          const isDogImage = Math.random() > 0.5;  // Aleatoriamente elegir entre perro o robot
          const title = book.title;

          if (isDogImage) {
            // Obtener la imagen del perro
            this.datosService.getRandomDogImage().subscribe((dogResponse: any) => {
              // Verificar si la respuesta contiene 'message' (URL de la imagen del perro)
              if (dogResponse && dogResponse.message) {
                this.bookList.push({ title, image: dogResponse.message });
              } else {
                console.error('Error: La respuesta del perro no contiene una URL válida');
              }
            }, (error) => {
              console.error('Error al obtener la imagen del perro:', error);
            });
          } else {
            // Obtener la imagen del robot
            this.datosService.getRandomRobotImage(`robot${index}`).subscribe((blob: Blob) => {
              const imageUrl = URL.createObjectURL(blob);  // Crear URL para la imagen del robot
              this.bookList.push({ title, image: imageUrl });
            }, (error) => {
              console.error('Error al obtener la imagen del robot:', error);
            });
          }
        });
      } else {
        console.error('Error: La respuesta no contiene los resultados esperados');
      }
    }, (error) => {
      console.error('Error al obtener los libros:', error);
    });
  }

  saveBook(book: { title: string; image: string }) {
    const booksCollection = collection(this.firestore, 'books');
    addDoc(booksCollection, book)
      .then(() => {
        console.log('Book added to Firestore');
      })
      .catch((error) => {
        console.error('Error adding book: ', error);
      });
  }
}
